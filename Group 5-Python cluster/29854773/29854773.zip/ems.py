# ems.py

import datetime

# Define a class for Event
class Event:
    def __init__(self, event_id, event_name, event_date, location, max_participants):
        self.event_id = event_id
        self.event_name = event_name
        self.event_date = event_date
        self.location = location
        self.max_participants = max_participants

# Define a class for Participant
class Participant:
    def __init__(self, participant_id, name, email, phone_number):
        self.participant_id = participant_id
        self.name = name
        self.email = email
        self.phone_number = phone_number

# Define a class for Registration
class Registration:
    def __init__(self, registration_id, event_id, participant_id, registration_date):
        self.registration_id = registration_id
        self.event_id = event_id
        self.participant_id = participant_id
        self.registration_date = registration_date

# Define the Event Management System class to manage events, participants, and registrations
class EventManagementSystem:
    def __init__(self):
        self.events = {}
        self.participants = {}
        self.registrations = {}

    # Method to add a new event
    def add_event(self, event):
        self.events[event.event_id] = event
        print(f"Event '{event.event_name}' added successfully.")

    # Method to update an existing event
    def update_event(self, event_id, event_name=None, event_date=None, location=None, max_participants=None):
        if event_id in self.events:
            if event_name:
                self.events[event_id].event_name = event_name
            if event_date:
                self.events[event_id].event_date = event_date
            if location:
                self.events[event_id].location = location
            if max_participants:
                self.events[event_id].max_participants = max_participants
            print(f"Event '{event_id}' updated successfully.")
        else:
            raise ValueError("Event ID not found")

    # Method to delete an event
    def delete_event(self, event_id):
        if event_id in self.events:
            del self.events[event_id]
            print(f"Event '{event_id}' deleted successfully.")
        else:
            raise ValueError("Event ID not found")

    # Method to add a new participant
    def add_participant(self, participant):
        self.participants[participant.participant_id] = participant
        print(f"Participant '{participant.name}' added successfully.")

    # Method to update an existing participant
    def update_participant(self, participant_id, name=None, email=None, phone_number=None):
        if participant_id in self.participants:
            if name:
                self.participants[participant_id].name = name
            if email:
                self.participants[participant_id].email = email
            if phone_number:
                self.participants[participant_id].phone_number = phone_number
            print(f"Participant '{participant_id}' updated successfully.")
        else:
            raise ValueError("Participant ID not found")

    # Method to delete a participant
    def delete_participant(self, participant_id):
        if participant_id in self.participants:
            del self.participants[participant_id]
            print(f"Participant '{participant_id}' deleted successfully.")
        else:
            raise ValueError("Participant ID not found")

    # Method to add a new registration
    def add_registration(self, registration):
        if registration.event_id in self.events and registration.participant_id in self.participants:
            self.registrations[registration.registration_id] = registration
            print(f"Registration '{registration.registration_id}' added successfully.")
        else:
            raise ValueError("Invalid event ID or participant ID")

    # Method to update an existing registration
    def update_registration(self, registration_id, event_id=None, participant_id=None, registration_date=None):
        if registration_id in self.registrations:
            if event_id:
                self.registrations[registration_id].event_id = event_id
            if participant_id:
                self.registrations[registration_id].participant_id = participant_id
            if registration_date:
                self.registrations[registration_id].registration_date = registration_date
            print(f"Registration '{registration_id}' updated successfully.")
        else:
            raise ValueError("Registration ID not found")

    # Method to delete a registration
    def delete_registration(self, registration_id):
        if registration_id in self.registrations:
            del self.registrations[registration_id]
            print(f"Registration '{registration_id}' deleted successfully.")
        else:
            raise ValueError("Registration ID not found")

    # Method to display all events
    def display_events(self):
        if not self.events:
            print("No events found.")
            return
        print("\nEvents:")
        # Displays a list of all events in a tabular format.
        print(f"{'Event ID':<10} {'Event Name':<20} {'Event Date':<15} {'Location':<20} {'Max Participants':<15}")
        for event in self.events.values():
            print(f"{event.event_id:<10} {event.event_name:<20} {event.event_date.strftime('%Y-%m-%d'):<15} {event.location:<20} {event.max_participants:<15}")

    # Method to display all participants
    def display_participants(self):
        if not self.participants:
            print("No participants found.")
            return
        print("\nParticipants:")
        # Displays a list of all participants in a tabular format.
        print(f"{'Participant ID':<15} {'Name':<20} {'Email':<30} {'Phone Number':<15}")
        for participant in self.participants.values():
            print(f"{participant.participant_id:<15} {participant.name:<20} {participant.email:<30} {participant.phone_number:<15}")

    # Method to display all registrations
    def display_registrations(self):
        if not self.registrations:
            print("No registrations found.")
            return
        print("\nRegistrations:")
        # Displays a list of all registrations in a tabular format.
        print(f"{'Registration ID':<15} {'Event ID':<10} {'Participant ID':<15} {'Registration Date':<15}")
        for registration in self.registrations.values():
            print(f"{registration.registration_id:<15} {registration.event_id:<10} {registration.participant_id:<15} {registration.registration_date.strftime('%Y-%m-%d'):<15}")

