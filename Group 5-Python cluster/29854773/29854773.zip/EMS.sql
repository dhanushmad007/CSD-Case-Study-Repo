-- creating DataBase
CREATE DATABASE event_management_system;

-- Using the DataBase
USE event_management_system;

-- Events Table
CREATE TABLE Events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    max_participants INT NOT NULL
);

-- Participants Table
CREATE TABLE Participants (
    participant_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL
);

-- Registrations Table
CREATE TABLE Registrations (
    registration_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    participant_id INT,
    registration_date DATE NOT NULL,
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
    FOREIGN KEY (participant_id) REFERENCES Participants(participant_id)
);

-- Query to find Total number of participants registered for each event
SELECT 
    e.event_id,
    e.event_name,
    COUNT(r.registration_id) AS total_participants
FROM 
    Events e
LEFT JOIN 
    Registrations r ON e.event_id = r.event_id
GROUP BY 
    e.event_id, e.event_name;

-- Query to find Details of events happening in the next month
SELECT 
    event_id,
    event_name,
    event_date,
    location,
    max_participants
FROM 
    Events
WHERE 
    YEAR(event_date) = YEAR(CURDATE())
    AND MONTH(event_date) = MONTH(CURDATE()) + 1;
    
-- Query to find Participants who have registered for more than one event
SELECT 
    p.participant_id,
    p.name,
    p.email,
    p.phone_number,
    COUNT(r.event_id) AS event_count
FROM 
    Participants p
JOIN 
    Registrations r ON p.participant_id = r.participant_id
GROUP BY 
    p.participant_id, p.name, p.email, p.phone_number
HAVING 
    COUNT(r.event_id) > 1;

-- Query to find Events that have reached their maximum participant capacity
SELECT 
    e.event_id,
    e.event_name,
    e.event_date,
    e.location,
    e.max_participants,
    COUNT(r.registration_id) AS total_participants
FROM 
    Events e
JOIN 
    Registrations r ON e.event_id = r.event_id
GROUP BY 
    e.event_id, e.event_name, e.event_date, e.location, e.max_participants
HAVING 
    COUNT(r.registration_id) >= e.max_participants;

-- Query to find Registration details for a specific participant
SELECT 
    r.registration_id,
    e.event_id,
    e.event_name,
    e.event_date,
    e.location,
    r.registration_date
FROM 
    Registrations r
JOIN 
    Events e ON r.event_id = e.event_id
WHERE 
    r.participant_id = 001;
