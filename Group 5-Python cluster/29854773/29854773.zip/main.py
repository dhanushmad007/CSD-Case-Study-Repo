# Import necessary classes and modules from ems.py
from ems import Event, Participant, Registration, EventManagementSystem
import datetime

# Main function to run the Event Management System
def main():
    # Create an instance of EventManagementSystem
    ems = EventManagementSystem()

    while True:
        # Display the main menu options
        print("\nEvent Management System")
        print("1. Event Management")
        print("2. Participant Management")
        print("3. Registration Management")
        print("4. Exit")

        # Prompt user to enter their choice
        choice = input("Enter your choice: ")

        try:
            match choice:
                case '1':  # Event Management
                    while True:
                        # Display event management options
                        print("\nEvent Management")
                        print("1. Add Event")
                        print("2. Update Event")
                        print("3. Delete Event")
                        print("4. Display Events")
                        print("5. Main Menu")
                        sub_choice = input("Enter your choice: ")

                        match sub_choice:
                            case '1':  # Add Event
                                # Prompt user to enter event details and add to the system
                                event_id = input("Enter event ID: ")
                                event_name = input("Enter event name: ")
                                event_date = input("Enter event date (YYYY-MM-DD): ")
                                location = input("Enter location: ")
                                max_participants = int(input("Enter max participants: "))
                                event_date = datetime.datetime.strptime(event_date, "%Y-%m-%d")
                                event = Event(event_id, event_name, event_date, location, max_participants)
                                ems.add_event(event)

                            case '2':  # Update Event
                                # Prompt user to update event details if the event exists
                                event_id = input("Enter event ID: ")
                                if event_id in ems.events.keys():
                                    event_name = input("Enter event name (leave blank if no change): ")
                                    event_date = input("Enter event date (YYYY-MM-DD, leave blank if no change): ")
                                    location = input("Enter location (leave blank if no change): ")
                                    max_participants = input("Enter max participants (leave blank if no change): ")
                                    max_participants = int(max_participants) if max_participants else None
                                    event_date = datetime.datetime.strptime(event_date, "%Y-%m-%d") if event_date else None
                                    ems.update_event(event_id, event_name, event_date, location, max_participants)
                                else:
                                    print(f'Event ID: {event_id} not found')

                            case '3':  # Delete Event
                                # Prompt user to delete an event by its ID
                                event_id = input("Enter event ID: ")
                                ems.delete_event(event_id)

                            case '4':  # Display Events
                                # Display all events currently managed by the system
                                ems.display_events()

                            case '5':  # Return to Main Menu
                                # Break out of the event management loop and return to main menu
                                break

                            case _:
                                print("Invalid choice. Please try again.")

                case '2':  # Participant Management
                    while True:
                        # Display participant management options
                        print("\nParticipant Management")
                        print("1. Add Participant")
                        print("2. Update Participant")
                        print("3. Delete Participant")
                        print("4. Display Participants")
                        print("5. Main Menu")
                        sub_choice = input("Enter your choice: ")

                        match sub_choice:
                            case '1':  # Add Participant
                                # Prompt user to enter participant details and add to the system
                                participant_id = input("Enter participant ID: ")
                                name = input("Enter name: ")
                                email = input("Enter email: ")
                                phone_number = input("Enter phone number: ")
                                participant = Participant(participant_id, name, email, phone_number)
                                ems.add_participant(participant)

                            case '2':  # Update Participant
                                # Prompt user to update participant details if the participant exists
                                participant_id = input("Enter participant ID: ")
                                if participant_id in ems.participants.keys():
                                    name = input("Enter name (leave blank if no change): ")
                                    email = input("Enter email (leave blank if no change): ")
                                    phone_number = input("Enter phone number (leave blank if no change): ")
                                    ems.update_participant(participant_id, name, email, phone_number)
                                else:
                                    print(f'Participant ID: {participant_id} not found')

                            case '3':  # Delete Participant
                                # Prompt user to delete a participant by their ID
                                participant_id = input("Enter participant ID: ")
                                ems.delete_participant(participant_id)

                            case '4':  # Display Participants
                                # Display all participants currently managed by the system
                                ems.display_participants()

                            case '5':  # Return to Main Menu
                                # Break out of the participant management loop and return to main menu
                                break

                            case _:
                                print("Invalid choice. Please try again.")

                case '3':  # Registration Management
                    while True:
                        # Display registration management options
                        print("\nRegistration Management")
                        print("1. Add Registration")
                        print("2. Update Registration")
                        print("3. Delete Registration")
                        print("4. Display Registrations")
                        print("5. Main Menu")
                        sub_choice = input("Enter your choice: ")

                        match sub_choice:
                            case '1':  # Add Registration
                                # Prompt user to enter registration details and add to the system
                                registration_id = input("Enter registration ID: ")
                                event_id = input("Enter event ID: ")
                                participant_id = input("Enter participant ID: ")
                                registration_date = input("Enter registration date (YYYY-MM-DD): ")
                                registration_date = datetime.datetime.strptime(registration_date, "%Y-%m-%d")
                                registration = Registration(registration_id, event_id, participant_id, registration_date)
                                ems.add_registration(registration)

                            case '2':  # Update Registration
                                # Prompt user to update registration details if the registration exists
                                registration_id = input("Enter registration ID: ")
                                if registration_id in ems.registrations.keys():
                                    event_id = input("Enter event ID (leave blank if no change): ")
                                    participant_id = input("Enter participant ID (leave blank if no change): ")
                                    registration_date = input("Enter registration date (YYYY-MM-DD, leave blank if no change): ")
                                    registration_date = datetime.datetime.strptime(registration_date, "%Y-%m-%d") if registration_date else None
                                    ems.update_registration(registration_id, event_id, participant_id, registration_date)
                                else:
                                    print(f'Registration ID: {registration_id} not found')

                            case '3':  # Delete Registration
                                # Prompt user to delete a registration by its ID
                                registration_id = input("Enter registration ID: ")
                                ems.delete_registration(registration_id)

                            case '4':  # Display Registrations
                                # Display all registrations currently managed by the system
                                ems.display_registrations()

                            case '5':  # Return to Main Menu
                                # Break out of the registration management loop and return to main menu
                                break

                            case _:
                                print("Invalid choice. Please try again.")

                case '4':  # Exit
                    # Exit the program
                    print("Exiting the Event Management System. Goodbye!")
                    return

                case _:
                    print("Invalid choice. Please try again.")

        except ValueError as ve:
            print(f"ValueError: {ve}")

        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
